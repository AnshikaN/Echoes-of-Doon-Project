<?php
// Database credentials
$servername = "localhost"; // Replace with your server name
$username = "username"; // Replace with your username
$password = "password"; // Replace with your password
$dbname = "echoesofdoon"; // Replace with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to retrieve event details from userTable
$sql = "SELECT * FROM userTable";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data of each row
    while ($row = $result->fetch_assoc()) {
        // Create event container for each event
        echo '<div class="event-box">';
        echo '<img src="' . $row["image"] . '" alt="' . $row["name"] . '">';
        echo '<h3>' . $row["name"] . '</h3>';
        echo '<p>' . $row["date"] . '</p>';
        echo '</div>';
    }
} else {
    echo "0 results";
}

// Close connection
$conn->close();
?>
